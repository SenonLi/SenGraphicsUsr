var searchData=
[
  ['tan',['tan',['../a00151.html#gab3ae890c38b7d3aa4d5e00998fd296b2',1,'glm']]],
  ['tanh',['tanh',['../a00151.html#ga234e904a0075f88654a594b5f837711f',1,'glm']]],
  ['third',['third',['../a00162.html#ga3077c6311010a214b69ddc8214ec13b5',1,'glm']]],
  ['three_5fover_5ftwo_5fpi',['three_over_two_pi',['../a00162.html#gae94950df74b0ce382b1fc1d978ef7394',1,'glm']]],
  ['to_5fstring',['to_string',['../a00228.html#ga7b4f9233593bbf1d53762f801ef56fe6',1,'glm']]],
  ['tomat3',['toMat3',['../a00220.html#ga01935b66ba245c2fd7dee5427d86ce9b',1,'glm']]],
  ['tomat4',['toMat4',['../a00220.html#gaedc9fba6485eade37cc26c16df9d7aad',1,'glm']]],
  ['toquat',['toQuat',['../a00220.html#gac9e3109ca60b644ce508d6b71a1697bc',1,'glm::toQuat(tmat3x3&lt; T, P &gt; const &amp;x)'],['../a00220.html#ga808dd0f83ee8150db7e652313bde8eb2',1,'glm::toQuat(tmat4x4&lt; T, P &gt; const &amp;x)']]],
  ['translate',['translate',['../a00169.html#gaee134ab77c6c5548a6ebf4e8e476c6ed',1,'glm::translate(tmat4x4&lt; T, P &gt; const &amp;m, tvec3&lt; T, P &gt; const &amp;v)'],['../a00209.html#ga22b5e806a6d2e2be54ebd29100d11c51',1,'glm::translate(tmat3x3&lt; T, P &gt; const &amp;m, tvec2&lt; T, P &gt; const &amp;v)'],['../a00229.html#ga838c4505ef7f254ed05117b1ac9691fb',1,'glm::translate(tvec3&lt; T, P &gt; const &amp;v)']]],
  ['trianglenormal',['triangleNormal',['../a00212.html#ga7842850bcda582f1756883e3ed950e14',1,'glm']]],
  ['trunc',['trunc',['../a00145.html#ga634cdbf8b37edca03f2248450570fd54',1,'glm']]],
  ['tweakedinfiniteperspective',['tweakedInfinitePerspective',['../a00169.html#gaed64bd81f5ecdab52fecbdf7f6b58194',1,'glm::tweakedInfinitePerspective(T fovy, T aspect, T near)'],['../a00169.html#gaa50fce7f50b5d5da881ed30f5532a921',1,'glm::tweakedInfinitePerspective(T fovy, T aspect, T near, T ep)']]],
  ['two_5fover_5fpi',['two_over_pi',['../a00162.html#ga74eadc8a211253079683219a3ea0462a',1,'glm']]],
  ['two_5fover_5froot_5fpi',['two_over_root_pi',['../a00162.html#ga5827301817640843cf02026a8d493894',1,'glm']]],
  ['two_5fpi',['two_pi',['../a00162.html#gaa5276a4617566abcfe49286f40e3a256',1,'glm']]],
  ['two_5fthirds',['two_thirds',['../a00162.html#ga9b4d2f4322edcf63a6737b92a29dd1f5',1,'glm']]]
];
